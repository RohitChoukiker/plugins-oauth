// Configuration file exporting client_id used to populate manifest during build.
// Keep this file out of public repositories if the client_id is sensitive.
module.exports = {
  client_id: "876513410741-agd6qc2kliptarjtm1gf4qeqvc0mk00k.apps.googleusercontent.com"
};
